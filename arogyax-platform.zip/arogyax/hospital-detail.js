// hospital-detail.js
let currentHospital = null;
let selectedRating = 0;

document.addEventListener("DOMContentLoaded", async () => {
  new SearchEngine({
    inputEl: document.getElementById("navSearchInput"),
    dropdownEl: document.getElementById("navDropdown"),
    onSelect: (id) => { window.location.href = `hospital.html?id=${id}`; }
  });

  const id = new URLSearchParams(window.location.search).get("id");
  if (!id) { showError(); return; }

  try {
    const all = await fetchAllHospitals();
    new SearchEngine({
      inputEl: document.getElementById("navSearchInput"),
      dropdownEl: document.getElementById("navDropdown"),
      onSelect: (hid) => { window.location.href = `hospital.html?id=${hid}`; }
    }).setHospitals(all);

    const h = all.find(x => x.id === id);
    if (!h) { showError(); return; }
    currentHospital = h;
    renderDetail(h);
    document.title = `${h.name} — ArogyaX`;
  } catch (e) {
    console.error(e); showError();
  }
});

function showError() {
  document.getElementById("loadingState").classList.add("hidden");
  document.getElementById("errorState").classList.remove("hidden");
}

function renderDetail(h) {
  document.getElementById("loadingState").classList.add("hidden");
  document.getElementById("detailPage").classList.remove("hidden");

  // Hero
  const img = (h.images && h.images[0]) || "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=1200&q=80";
  const heroImg = document.getElementById("heroImg");
  heroImg.src = img;
  heroImg.alt = h.name;
  heroImg.onerror = () => heroImg.src = "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1200&q=80";
  document.getElementById("heroName").textContent = h.name;
  document.getElementById("heroArea").textContent = `📍 ${h.area}, ${h.city}`;
  document.getElementById("heroRating").textContent = h.rating;
  const typeBadge = document.getElementById("heroTypeBadge");
  typeBadge.textContent = h.type;
  typeBadge.className = `type-badge ${getTypeBadgeClass(h.type)}`;
  const emg = emergencyBadge(h.emergency_score || 0);
  const emgBadge = document.getElementById("heroEmgBadge");
  emgBadge.textContent = `⚡ ${emg.label} Emergency`;
  emgBadge.className = `emg-badge ${emg.cls}`;
  const dirEl = document.getElementById("heroDirections");
  dirEl.href = h.map_link || `https://maps.google.com/?q=${encodeURIComponent(h.name + ' ' + h.area)}`;
  updateHeroCompareBtn();

  // Gallery
  const gallery = document.getElementById("galleryStrip");
  if (h.images && h.images.length > 1) {
    gallery.innerHTML = h.images.map((src, i) => `
      <img src="${sanitize(src)}" alt="${sanitize(h.name)} ${i+1}" loading="lazy"
        class="gallery-thumb ${i===0?'active':''}"
        onerror="this.src='https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&q=70'"
        onclick="setHeroImg('${sanitize(src)}', this)">
    `).join("");
  }

  // AI Summary
  document.getElementById("aiSummary").textContent = generateAISummary(h);

  // Overview
  const og = document.getElementById("overviewGrid");
  og.innerHTML = `
    <div class="ov-item"><span class="ov-label">Type</span><span>${sanitize(h.type)}</span></div>
    <div class="ov-item"><span class="ov-label">Area</span><span>${sanitize(h.area)}</span></div>
    <div class="ov-item"><span class="ov-label">Emergency Score</span><span>${h.emergency_score || 'N/A'}/100</span></div>
    <div class="ov-item"><span class="ov-label">Doctors</span><span>${h.doctors_count || 'N/A'}</span></div>
    <div class="ov-item ov-full"><span class="ov-label">Address</span><span>${sanitize(h.address)}</span></div>
  `;

  // Costs
  const costs = estimateCosts(h);
  document.getElementById("costGrid").innerHTML = costs.items.map(c => `
    <div class="cost-item">
      <span class="cost-label">${sanitize(c.label)}</span>
      <span class="cost-range">${sanitize(c.range)}</span>
    </div>
  `).join("");
  document.getElementById("costNote").textContent = costs.note;

  // Pros/Cons
  document.getElementById("prosList").innerHTML = (h.pros || []).map(p => `<li>${sanitize(p)}</li>`).join("");
  document.getElementById("consList").innerHTML = (h.cons || []).map(c => `<li>${sanitize(c)}</li>`).join("");

  // Facilities
  document.getElementById("facilitiesGrid").innerHTML = (h.facilities || []).map(f => `
    <span class="facility-chip">✓ ${sanitize(f)}</span>
  `).join("");
  document.getElementById("amenitiesList").innerHTML = (h.amenities || []).map(a => `
    <span class="amenity-chip">${sanitize(a)}</span>
  `).join("");

  // Specialties
  document.getElementById("specTags").innerHTML = (h.specialties || []).map(s => `<span class="spec-tag">${sanitize(s)}</span>`).join("");
  document.getElementById("bestForTags").innerHTML = (h.best_for || []).map(b => `<span class="bestfor-tag">${sanitize(b)}</span>`).join("");

  // Scores
  const emgPct = h.emergency_score || 0;
  const affPct = ((h.affordability_score || 3) / 5) * 100;
  const ratPct = ((h.rating || 0) / 5) * 100;
  document.getElementById("emgBar").style.width = emgPct + "%";
  document.getElementById("affBar").style.width = affPct + "%";
  document.getElementById("ratBar").style.width = ratPct + "%";
  document.getElementById("emgScore").textContent = emgPct + "/100";
  document.getElementById("affScore").textContent = affordabilityLabel(h.affordability_score);
  document.getElementById("ratScore").textContent = h.rating + "/5";

  // Quick info
  document.getElementById("qiWait").textContent = h.waiting_time || "N/A";
  document.getElementById("qiTravel").textContent = h.travel_time || "N/A";
  document.getElementById("qiDoctors").textContent = h.doctors_count ? `${h.doctors_count}+ on staff` : "N/A";
  document.getElementById("qiType").textContent = h.type;

  // Map
  const mapEmbed = document.getElementById("mapEmbed");
  if (h.lat && h.lng) {
    mapEmbed.innerHTML = `
      <iframe
        src="https://maps.google.com/maps?q=${h.lat},${h.lng}&z=15&output=embed"
        width="100%" height="220" style="border:0;border-radius:12px;" loading="lazy"
        allowfullscreen referrerpolicy="no-referrer-when-downgrade"></iframe>
    `;
  } else {
    mapEmbed.innerHTML = `<div class="map-placeholder">Map unavailable</div>`;
  }
  document.getElementById("mapAddress").textContent = h.address;
  document.getElementById("mapLink").href = h.map_link || `https://maps.google.com/?q=${encodeURIComponent(h.address)}`;

  // Report link
  document.getElementById("reportLink").href = `contact.html?hospital=${encodeURIComponent(h.name)}`;

  // Reviews
  renderReviews(h.id);
  initStarSelector();

  // Scroll reveal
  initScrollReveal();
}

function setHeroImg(src, el) {
  document.getElementById("heroImg").src = src;
  document.querySelectorAll(".gallery-thumb").forEach(t => t.classList.remove("active"));
  el.classList.add("active");
}

function generateAISummary(h) {
  const name = h.name;
  const emg = h.emergency_score >= 85 ? "strong emergency readiness" : h.emergency_score >= 70 ? "moderate emergency coverage" : "basic emergency services";
  const wait = h.waiting_time || "variable wait times";
  const spec = (h.specialties || []).slice(0, 2).join(" and ");
  const aff = h.affordability_score >= 4 ? "an affordable option" : h.affordability_score === 3 ? "moderately priced" : "a premium-tier facility";
  const area = h.area;
  return `${name} in ${area} offers ${emg} with ${aff} positioning. Known for ${spec}, the hospital sees ${wait} in OPD. ${(h.pros || [])[0] || ""}. Patients should note: ${(h.cons || [])[0] || "check current availability"}.`;
}

function estimateCosts(h) {
  const a = h.affordability_score || 3;
  const costMap = {
    5: { op: "Free – ₹50", icu: "Free – ₹2,000/day", note: "Government schemes may apply. Bring ID proof and referral." },
    4: { op: "₹100 – ₹500", icu: "₹2,000 – ₹5,000/day", note: "Budget-friendly. Some procedures may require advance payment." },
    3: { op: "₹500 – ₹1,500", icu: "₹5,000 – ₹12,000/day", note: "Mid-range pricing. Insurance typically accepted." },
    2: { op: "₹1,500 – ₹3,000", icu: "₹12,000 – ₹25,000/day", note: "Premium facility. Insurance highly recommended." },
    1: { op: "₹3,000+", icu: "₹25,000+/day", note: "Ultra-premium pricing. International-grade billing." }
  };
  const c = costMap[a] || costMap[3];
  return {
    items: [
      { label: "OPD Consultation", range: c.op },
      { label: "ICU (per day)", range: c.icu },
      { label: "Specialist Consultation", range: a >= 4 ? "₹200–₹800" : a === 3 ? "₹800–₹2,000" : "₹2,000–₹5,000" },
      { label: "Diagnostic Package", range: a >= 4 ? "₹500–₹2,000" : a === 3 ? "₹2,000–₹6,000" : "₹6,000–₹15,000" }
    ],
    note: c.note
  };
}

// ── Reviews ──────────────────────────────────────────────────────────────────
function getReviewsKey(id) { return `arogyax_reviews_${id}`; }

function getReviews(id) {
  try { return JSON.parse(localStorage.getItem(getReviewsKey(id)) || "[]"); } catch { return []; }
}

function saveReviews(id, reviews) {
  localStorage.setItem(getReviewsKey(id), JSON.stringify(reviews));
}

const DEFAULT_REVIEWS = {
  "apollo-jubilee-hills": [
    { rating: 5, text: "Excellent cardiac team. Dr. Ramesh was incredibly thorough.", date: "2025-01-10" },
    { rating: 3, text: "OPD wait was nearly 2 hours on Saturday. Specialist not available.", date: "2025-01-22" }
  ],
  "yashoda-secunderabad": [
    { rating: 4, text: "Neurology dept is very good. Clean ICU.", date: "2025-01-15" },
    { rating: 3, text: "Billing process is slow but treatment was good.", date: "2025-01-28" }
  ],
  "kims-secunderabad": [
    { rating: 4, text: "Great orthopedic team. My knee replacement went smoothly.", date: "2025-01-20" },
    { rating: 4, text: "Maternity ward very well managed. Staff very helpful.", date: "2025-02-01" }
  ]
};

function renderReviews(id) {
  let reviews = getReviews(id);
  if (!reviews.length && DEFAULT_REVIEWS[id]) reviews = DEFAULT_REVIEWS[id];

  if (!reviews.length) {
    document.getElementById("reviewSummary").innerHTML = `<p class="no-reviews">No reviews yet. Be the first!</p>`;
    document.getElementById("reviewsList").innerHTML = "";
    return;
  }

  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  document.getElementById("reviewSummary").innerHTML = `
    <div class="rev-summary-row">
      <div class="rev-avg">⭐ ${avg}</div>
      <div class="rev-count">${reviews.length} review${reviews.length !== 1 ? "s" : ""}</div>
    </div>
  `;
  document.getElementById("reviewsList").innerHTML = reviews.map(r => `
    <div class="review-item">
      <div class="review-stars">${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</div>
      <p class="review-text">${sanitize(r.text)}</p>
      <span class="review-date">${r.date || ""}</span>
    </div>
  `).join("");
}

function initStarSelector() {
  const stars = document.querySelectorAll(".star");
  stars.forEach(s => {
    s.addEventListener("mouseenter", () => {
      const v = +s.dataset.v;
      stars.forEach(x => x.classList.toggle("hover", +x.dataset.v <= v));
    });
    s.addEventListener("mouseleave", () => stars.forEach(x => x.classList.remove("hover")));
    s.addEventListener("click", () => {
      selectedRating = +s.dataset.v;
      stars.forEach(x => x.classList.toggle("selected", +x.dataset.v <= selectedRating));
    });
  });
}

function submitReview() {
  const text = document.getElementById("reviewText").value.trim();
  const msg = document.getElementById("reviewMsg");
  if (!selectedRating) { msg.textContent = "Please select a star rating."; msg.className = "review-msg error"; return; }
  if (text.length < 10) { msg.textContent = "Please write at least 10 characters."; msg.className = "review-msg error"; return; }
  const id = currentHospital.id;
  const reviews = getReviews(id);
  const today = new Date().toISOString().split("T")[0];
  reviews.unshift({ rating: selectedRating, text, date: today });
  saveReviews(id, reviews);
  renderReviews(id);
  document.getElementById("reviewText").value = "";
  selectedRating = 0;
  document.querySelectorAll(".star").forEach(s => s.classList.remove("selected"));
  msg.textContent = "✓ Review submitted. Thank you!";
  msg.className = "review-msg success";
  setTimeout(() => { msg.textContent = ""; }, 4000);
}

function toggleDetailCompare() {
  if (!currentHospital) return;
  CompareState.toggle(currentHospital.id);
  updateHeroCompareBtn();
  updateCompareUI();
}

function updateHeroCompareBtn() {
  if (!currentHospital) return;
  const btn = document.getElementById("heroCompareBtn");
  const inComp = CompareState.has(currentHospital.id);
  btn.textContent = inComp ? "✓ In Compare" : "+ Add to Compare";
  btn.classList.toggle("added", inComp);
}
