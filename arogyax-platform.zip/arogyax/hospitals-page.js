// hospitals-page.js
let allHospitals = [];
let navSearch;

document.addEventListener("DOMContentLoaded", async () => {
  navSearch = new SearchEngine({
    inputEl: document.getElementById("navSearchInput"),
    dropdownEl: document.getElementById("navDropdown"),
    onSelect: (id) => { window.location.href = `hospital.html?id=${id}`; }
  });

  try {
    allHospitals = await fetchAllHospitals();
    navSearch.setHospitals(allHospitals);
    populateFilters();
    loadURLParams();
    applyFilters();
  } catch (err) {
    console.error(err);
    document.getElementById("hospitalsGrid").innerHTML =
      `<div class="error-msg">Failed to load data. Please refresh.</div>`;
  }
});

function populateFilters() {
  // Areas
  const areas = [...new Set(allHospitals.map(h => h.area))].sort();
  const areaEl = document.getElementById("f-area");
  areas.forEach(a => {
    const opt = document.createElement("option");
    opt.value = a; opt.textContent = a;
    areaEl.appendChild(opt);
  });

  // Specialties
  const specs = [...new Set(allHospitals.flatMap(h => h.specialties || []))].sort();
  const specList = document.getElementById("f-spec-list");
  specs.forEach(s => {
    const lbl = document.createElement("label");
    lbl.innerHTML = `<input type="checkbox" value="${sanitize(s)}" onchange="applyFilters()"> ${sanitize(s)}`;
    specList.appendChild(lbl);
  });
}

function loadURLParams() {
  const p = new URLSearchParams(window.location.search);
  const search = p.get("search");
  const type = p.get("type");
  const specialty = p.get("specialty");
  const emergency = p.get("emergency");

  if (search) {
    document.getElementById("navSearchInput").value = search;
  }
  if (type) {
    const cb = document.querySelector(`#f-type-list input[value="${type}"]`);
    if (cb) cb.checked = true;
  }
  if (specialty) {
    const cb = document.querySelector(`#f-spec-list input[value="${specialty}"]`);
    if (cb) cb.checked = true;
  }
  if (emergency === "true") {
    document.getElementById("f-emg").value = 75;
    document.getElementById("emgVal").textContent = "75+";
  }
}

function getActiveFilters() {
  const search = (document.getElementById("navSearchInput")?.value || "").trim();
  const area = document.getElementById("f-area").value;
  const types = [...document.querySelectorAll("#f-type-list input:checked")].map(e => e.value);
  const minRating = parseFloat(document.getElementById("f-rating").value) || 0;
  const specs = [...document.querySelectorAll("#f-spec-list input:checked")].map(e => e.value);
  const minEmg = parseInt(document.getElementById("f-emg").value) || 0;
  const affords = [...document.querySelectorAll("#f-afford-list input:checked")].map(e => +e.value);
  const facs = [...document.querySelectorAll("#f-fac-list input:checked")].map(e => e.value);
  const sort = document.getElementById("sortSelect").value;
  return { search, area, types, minRating, specs, minEmg, affords, facs, sort };
}

function applyFilters() {
  const f = getActiveFilters();
  let results = allHospitals.filter(h => {
    if (f.search) {
      const score = scoreMatch(h, f.search);
      if (score === 0) return false;
    }
    if (f.area && h.area !== f.area) return false;
    if (f.types.length && !f.types.includes(h.type)) return false;
    if (f.minRating > 0 && (h.rating || 0) < f.minRating) return false;
    if (f.specs.length && !f.specs.every(s => (h.specialties || []).includes(s))) return false;
    if (f.minEmg > 0 && (h.emergency_score || 0) < f.minEmg) return false;
    if (f.affords.length && !f.affords.includes(h.affordability_score)) return false;
    if (f.facs.length && !f.facs.every(fac => (h.facilities || []).includes(fac))) return false;
    return true;
  });

  // Sort
  results = sortHospitals(results, f.sort, f.search);

  // Update URL
  const params = new URLSearchParams();
  if (f.search) params.set("search", f.search);
  if (f.area) params.set("area", f.area);
  if (f.types.length) params.set("type", f.types.join(","));
  window.history.replaceState(null, "", "?" + params.toString());

  // Render
  renderGrid(results);
  renderActiveFilters(f);
}

function sortHospitals(arr, sort, search) {
  if (sort === "rating") return arr.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  if (sort === "emergency") return arr.sort((a, b) => (b.emergency_score || 0) - (a.emergency_score || 0));
  if (sort === "afford-asc") return arr.sort((a, b) => (b.affordability_score || 0) - (a.affordability_score || 0));
  if (sort === "afford-desc") return arr.sort((a, b) => (a.affordability_score || 0) - (b.affordability_score || 0));
  if (sort === "name") return arr.sort((a, b) => a.name.localeCompare(b.name));
  return arr;
}

function renderGrid(hospitals) {
  const grid = document.getElementById("hospitalsGrid");
  const noRes = document.getElementById("noResults");
  const count = document.getElementById("resultsCount");
  count.textContent = `${hospitals.length} hospital${hospitals.length !== 1 ? "s" : ""} found`;
  if (!hospitals.length) {
    grid.innerHTML = "";
    noRes.classList.remove("hidden");
    return;
  }
  noRes.classList.add("hidden");
  grid.innerHTML = hospitals.map(h => buildHospitalCard(h)).join("");
  initScrollReveal();
}

function renderActiveFilters(f) {
  const el = document.getElementById("activeFilters");
  const tags = [];
  if (f.search) tags.push(`Search: "${f.search}" <button onclick="clearSearch()">×</button>`);
  if (f.area) tags.push(`Area: ${f.area} <button onclick="clearArea()">×</button>`);
  f.types.forEach(t => tags.push(`Type: ${t} <button onclick="clearType('${t}')">×</button>`));
  f.specs.forEach(s => tags.push(`Specialty: ${s} <button onclick="clearSpec('${s}')">×</button>`));
  el.innerHTML = tags.map(t => `<span class="active-filter-tag">${t}</span>`).join("");
}

function clearAllFilters() {
  document.getElementById("f-area").value = "";
  document.querySelectorAll(".checkbox-list input").forEach(cb => cb.checked = false);
  document.getElementById("f-rating").value = 0;
  document.getElementById("ratingVal").textContent = "Any";
  document.getElementById("f-emg").value = 0;
  document.getElementById("emgVal").textContent = "Any";
  document.getElementById("navSearchInput").value = "";
  window.history.replaceState(null, "", "hospitals.html");
  applyFilters();
}
function clearSearch() { document.getElementById("navSearchInput").value = ""; applyFilters(); }
function clearArea() { document.getElementById("f-area").value = ""; applyFilters(); }
function clearType(t) { const cb = document.querySelector(`#f-type-list input[value="${t}"]`); if (cb) cb.checked = false; applyFilters(); }
function clearSpec(s) { const cb = document.querySelector(`#f-spec-list input[value="${s}"]`); if (cb) cb.checked = false; applyFilters(); }

function openMobileFilters() { document.getElementById("filtersSidebar").classList.add("mobile-open"); }
function closeMobileFilters() { document.getElementById("filtersSidebar").classList.remove("mobile-open"); }
