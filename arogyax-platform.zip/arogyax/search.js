// search.js — Play Store-level instant search

function sanitize(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function normalise(s) {
  return (s || "").toLowerCase().replace(/\s+/g, " ").trim();
}

function scoreMatch(hospital, query) {
  const q = normalise(query);
  const name = normalise(hospital.name);
  const area = normalise(hospital.area);
  const specs = (hospital.specialties || []).map(normalise).join(" ");
  const bestFor = (hospital.best_for || []).map(normalise).join(" ");
  const type = normalise(hospital.type);

  let score = 0;
  if (name.startsWith(q)) score += 100;
  else if (name.includes(q)) score += 70;
  if (area.includes(q)) score += 50;
  if (specs.includes(q)) score += 40;
  if (bestFor.includes(q)) score += 35;
  if (type.includes(q)) score += 20;

  // Fuzzy: check each word in query
  const words = q.split(" ").filter(Boolean);
  words.forEach(w => {
    if (w.length < 2) return;
    if (name.includes(w)) score += 15;
    if (area.includes(w)) score += 10;
    if (specs.includes(w)) score += 8;
  });

  return score;
}

function highlightText(text, query) {
  if (!query) return sanitize(text);
  const safe = sanitize(text);
  const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return safe.replace(new RegExp(`(${escaped})`, "gi"), "<mark>$1</mark>");
}

function getTypeBadgeClass(type) {
  const map = {
    "Government": "badge-gov",
    "Corporate": "badge-corp",
    "Private": "badge-priv",
    "Clinic": "badge-clinic"
  };
  return map[type] || "badge-priv";
}

class SearchEngine {
  constructor({ inputEl, dropdownEl, onSelect, hospitals = [] }) {
    this.input = inputEl;
    this.dropdown = dropdownEl;
    this.onSelect = onSelect;
    this.hospitals = hospitals;
    this.activeIdx = -1;
    this._bind();
  }

  setHospitals(arr) { this.hospitals = arr; }

  _bind() {
    this.input.addEventListener("input", () => this._onInput());
    this.input.addEventListener("keydown", (e) => this._onKey(e));
    document.addEventListener("click", (e) => {
      if (!this.input.contains(e.target) && !this.dropdown.contains(e.target)) {
        this._close();
      }
    });
    this.input.addEventListener("focus", () => {
      if (this.input.value.trim()) this._onInput();
    });
  }

  _onInput() {
    const q = this.input.value.trim();
    if (!q) { this._close(); return; }
    const results = this._search(q);
    this._render(results, q);
  }

  _search(q) {
    return this.hospitals
      .map(h => ({ h, score: scoreMatch(h, q) }))
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 7)
      .map(x => x.h);
  }

  _render(results, q) {
    this.activeIdx = -1;
    if (!results.length) {
      this.dropdown.innerHTML = `<div class="dd-empty">No hospitals found for "<b>${sanitize(q)}</b>"</div>`;
      this.dropdown.classList.add("open");
      return;
    }
    this.dropdown.innerHTML = results.map((h, i) => `
      <div class="dd-item" data-idx="${i}" data-id="${sanitize(h.id)}" role="option">
        <div class="dd-icon">🏥</div>
        <div class="dd-info">
          <div class="dd-name">${highlightText(h.name, q)}</div>
          <div class="dd-meta">${highlightText(h.area, q)} · <span class="badge ${getTypeBadgeClass(h.type)}">${sanitize(h.type)}</span></div>
        </div>
        <div class="dd-rating">⭐ ${h.rating}</div>
      </div>
    `).join("");
    this.dropdown.classList.add("open");
    this.dropdown.querySelectorAll(".dd-item").forEach(item => {
      item.addEventListener("mousedown", (e) => {
        e.preventDefault();
        const id = item.dataset.id;
        this._close();
        if (this.onSelect) this.onSelect(id, results[+item.dataset.idx]);
      });
    });
  }

  _onKey(e) {
    const items = this.dropdown.querySelectorAll(".dd-item");
    if (!items.length) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      this.activeIdx = Math.min(this.activeIdx + 1, items.length - 1);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      this.activeIdx = Math.max(this.activeIdx - 1, 0);
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (this.activeIdx >= 0) items[this.activeIdx].dispatchEvent(new Event("mousedown"));
      else {
        // Go to search results page
        const q = this.input.value.trim();
        if (q) window.location.href = `hospitals.html?search=${encodeURIComponent(q)}`;
      }
      return;
    } else if (e.key === "Escape") {
      this._close(); return;
    } else return;
    items.forEach((el, i) => el.classList.toggle("dd-active", i === this.activeIdx));
  }

  _close() {
    this.dropdown.classList.remove("open");
    this.dropdown.innerHTML = "";
    this.activeIdx = -1;
  }
}
