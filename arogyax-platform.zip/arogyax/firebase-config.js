// firebase-config.js
const firebaseConfig = {
  apiKey: "AIzaSyAq-JQf7QdhFWrXS2HzURKcK4RlOLYLSSo",
  authDomain: "arogyax-1.firebaseapp.com",
  projectId: "arogyax-1",
  storageBucket: "arogyax-1.firebasestorage.app",
  messagingSenderId: "229877645014",
  appId: "1:229877645014:web:e34a3012b6b3eca6b85377",
  measurementId: "G-FE9RKJ8ZBR"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
