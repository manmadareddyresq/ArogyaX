// compare-page.js
document.addEventListener("DOMContentLoaded", async () => {
  new SearchEngine({
    inputEl: document.getElementById("navSearchInput"),
    dropdownEl: document.getElementById("navDropdown"),
    onSelect: (id) => window.location.href = `hospital.html?id=${id}`
  });

  try {
    const all = await fetchAllHospitals();
    window._allHospitals = all;
    new SearchEngine({
      inputEl: document.getElementById("navSearchInput"),
      dropdownEl: document.getElementById("navDropdown"),
      onSelect: (id) => window.location.href = `hospital.html?id=${id}`
    }).setHospitals(all);
  } catch (e) { console.error(e); }

  document.addEventListener("compare-changed", renderCompare);
  renderCompare();
});

function renderCompare() {
  const ids = CompareState.get();
  const all = window._allHospitals || [];
  const hospitals = ids.map(id => all.find(h => h.id === id)).filter(Boolean);

  document.getElementById("emptyCompare").classList.toggle("hidden", hospitals.length > 0);
  document.getElementById("compareContent").classList.toggle("hidden", hospitals.length === 0);
  updateCompareUI();

  if (!hospitals.length) return;
  buildCompareTable(hospitals);
}

const COMPARE_ROWS = [
  { key: "name", label: "Hospital", type: "link" },
  { key: "area", label: "📍 Area", type: "text" },
  { key: "type", label: "🏷️ Type", type: "badge" },
  { key: "rating", label: "⭐ Overall Rating", type: "number", best: "high", max: 5 },
  { key: "emergency_score", label: "🚨 Emergency Score", type: "bar", best: "high", max: 100 },
  { key: "affordability_score", label: "💰 Affordability", type: "afford", best: "high" },
  { key: "waiting_time", label: "⏱ Waiting Time OPD", type: "text" },
  { key: "travel_time", label: "🚗 Travel Time", type: "text" },
  { key: "doctors_count", label: "👨‍⚕️ Doctors on Staff", type: "number", best: "high" },
  { key: "icu", label: "🏥 ICU", type: "facility", fac: "ICU" },
  { key: "nicu", label: "👶 NICU", type: "facility", fac: "NICU" },
  { key: "cath_lab", label: "❤️ Cath Lab", type: "facility", fac: "Cath Lab" },
  { key: "mri", label: "🔬 MRI", type: "facility", fac: "MRI" },
  { key: "ct_scan", label: "🔬 CT Scan", type: "facility", fac: "CT Scan" },
  { key: "dialysis", label: "💉 Dialysis", type: "facility", fac: "Dialysis" },
  { key: "blood_bank", label: "🩸 Blood Bank", type: "facility", fac: "Blood Bank" },
  { key: "pharmacy_24", label: "💊 24/7 Pharmacy", type: "facility", fac: "24/7 Pharmacy" },
  { key: "ambulance", label: "🚑 Ambulance", type: "facility", fac: "Ambulance" },
  { key: "robotic", label: "🤖 Robotic Surgery", type: "facility", fac: "Robotic Surgery" },
  { key: "wifi", label: "📶 WiFi", type: "amenity", amen: "Wifi" },
  { key: "parking", label: "🅿️ Parking", type: "amenity", amen: "Parking" },
  { key: "cafeteria", label: "🍽️ Cafeteria", type: "amenity", amen: "Cafeteria" },
  { key: "specialties", label: "🩺 Specialties", type: "list", field: "specialties" },
  { key: "best_for", label: "🎯 Best For", type: "list", field: "best_for" },
  { key: "pros_summary", label: "✅ Top Pro", type: "first", field: "pros" },
  { key: "cons_summary", label: "⚠️ Main Con", type: "first", field: "cons" },
  { key: "action", label: "", type: "action" }
];

function getBestIndices(hospitals, row) {
  if (row.best === "high") {
    const vals = hospitals.map(h => {
      if (row.type === "number") return h[row.key] || 0;
      if (row.type === "bar") return h[row.key] || 0;
      if (row.type === "afford") return h.affordability_score || 0;
      return 0;
    });
    const max = Math.max(...vals);
    return vals.map((v, i) => v === max ? i : -1).filter(i => i >= 0);
  }
  return [];
}

function cellValue(h, row) {
  switch (row.type) {
    case "link":
      return `<a href="hospital.html?id=${sanitize(h.id)}" class="comp-name">${sanitize(h.name)}</a>`;
    case "text":
      return sanitize(h[row.key] || "N/A");
    case "badge":
      return `<span class="badge ${getTypeBadgeClass(h.type)}">${sanitize(h.type)}</span>`;
    case "number":
      return `<b>${h[row.key] || "N/A"}</b>`;
    case "bar":
      const v = h[row.key] || 0;
      return `<div class="comp-bar-wrap"><div class="comp-bar" style="width:${v}%"></div></div><span>${v}/100</span>`;
    case "afford":
      return `<span class="afford-label" style="color:${affordabilityColor(h.affordability_score)}">${affordabilityLabel(h.affordability_score)}</span>`;
    case "facility":
      const hasFac = (h.facilities || []).includes(row.fac);
      return hasFac ? `<span class="check yes">✓</span>` : `<span class="check no">✗</span>`;
    case "amenity":
      const hasAmen = (h.amenities || []).some(a => a.toLowerCase().includes(row.amen.toLowerCase()));
      return hasAmen ? `<span class="check yes">✓</span>` : `<span class="check no">✗</span>`;
    case "list":
      return (h[row.field] || []).slice(0, 4).map(s => `<span class="tag-sm">${sanitize(s)}</span>`).join("");
    case "first":
      return sanitize((h[row.field] || [])[0] || "—");
    case "action":
      return `
        <div class="comp-actions">
          <a href="hospital.html?id=${sanitize(h.id)}" class="btn-view-sm">View</a>
          <button onclick="CompareState.remove('${sanitize(h.id)}'); renderCompare();" class="btn-remove-sm">Remove</button>
        </div>
      `;
    default: return "—";
  }
}

function buildCompareTable(hospitals) {
  const table = document.getElementById("compareTable");
  let html = "";

  // Header row
  html += `<thead><tr><th class="row-label-col">Parameter</th>`;
  hospitals.forEach(h => {
    const img = (h.images && h.images[0]) || "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=400&q=70";
    html += `<th>
      <div class="comp-hospital-header">
        <img src="${sanitize(img)}" alt="${sanitize(h.name)}"
          onerror="this.src='https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400&q=70'">
        <span>${sanitize(h.name)}</span>
        <span class="badge ${getTypeBadgeClass(h.type)}">${sanitize(h.type)}</span>
      </div>
    </th>`;
  });
  html += `</tr></thead>`;

  // Body rows
  html += `<tbody>`;
  COMPARE_ROWS.forEach(row => {
    const bestIdx = getBestIndices(hospitals, row);
    html += `<tr class="comp-row">`;
    if (row.type !== "action") {
      html += `<td class="row-label">${row.label}</td>`;
    } else {
      html += `<td class="row-label"></td>`;
    }
    hospitals.forEach((h, i) => {
      const isBest = bestIdx.includes(i);
      html += `<td class="${isBest ? 'best-cell' : ''}">${cellValue(h, row)}</td>`;
    });
    html += `</tr>`;
  });
  html += `</tbody>`;

  table.innerHTML = html;
}
