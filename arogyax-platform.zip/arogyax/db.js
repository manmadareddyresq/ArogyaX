// db.js — Firestore data layer + seed data

const HOSPITALS_COLLECTION = "hospitals";

// ── Seed data (written to Firestore once if collection is empty) ─────────────
const SEED_HOSPITALS = [
  {
    id: "apollo-jubilee-hills",
    name: "Apollo Hospitals",
    city: "Hyderabad",
    area: "Jubilee Hills",
    address: "Plot No. 251, Jubilee Hills, Hyderabad — 500033",
    lat: 17.4318,
    lng: 78.4073,
    map_link: "https://maps.google.com/?q=Apollo+Hospitals+Jubilee+Hills+Hyderabad",
    rating: 4.5,
    type: "Corporate",
    doctors_count: 280,
    facilities: ["ICU", "NICU", "Cath Lab", "MRI", "CT Scan", "PET Scan", "Dialysis", "Blood Bank", "24/7 Pharmacy", "Ambulance"],
    amenities: ["Valet Parking", "Food Court", "Wifi", "Prayer Room", "ATM", "International Patient Desk", "Concierge"],
    specialties: ["Cardiology", "Neurology", "Oncology", "Orthopedics", "Transplant", "Robotic Surgery", "Nephrology"],
    best_for: ["Cardiac Surgeries", "Organ Transplants", "Cancer Care", "Robotic Procedures"],
    pros: ["World-class infrastructure", "JCI accredited", "Experienced senior consultants", "Strong ICU setup", "International patient support"],
    cons: ["Very high consultation fees", "Long wait for senior doctors", "Parking congestion", "Appointment delays common"],
    emergency_score: 95,
    affordability_score: 2,
    waiting_time: "45–90 min OPD",
    travel_time: "20 min from Hitech City",
    images: [
      "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=800&q=80",
      "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&q=80"
    ]
  },
  {
    id: "yashoda-secunderabad",
    name: "Yashoda Hospitals",
    city: "Hyderabad",
    area: "Secunderabad",
    address: "Nalgonda X Road, Malakpet, Hyderabad — 500036",
    lat: 17.4239,
    lng: 78.5196,
    map_link: "https://maps.google.com/?q=Yashoda+Hospitals+Secunderabad",
    rating: 4.3,
    type: "Corporate",
    doctors_count: 220,
    facilities: ["ICU", "NICU", "Cath Lab", "MRI", "CT Scan", "Dialysis", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Trauma Centre"],
    amenities: ["Paid Parking", "Cafeteria", "Wifi", "ATM", "Pharmacy Retail"],
    specialties: ["Cardiology", "Neurology", "Gastroenterology", "Orthopedics", "Urology", "Pulmonology"],
    best_for: ["Neurology Cases", "Cardiac Emergencies", "Gastrointestinal Surgeries"],
    pros: ["Strong neurology department", "Accessible from old city", "Decent pricing vs Apollo", "Good trauma response"],
    cons: ["Older building infrastructure in some wings", "Moderate parking space", "Specialist availability varies by day"],
    emergency_score: 88,
    affordability_score: 3,
    waiting_time: "30–60 min OPD",
    travel_time: "15 min from Secunderabad station",
    images: [
      "https://images.unsplash.com/photo-1551190822-a9333d879b1f?w=800&q=80",
      "https://images.unsplash.com/photo-1632833239869-a37e3a5806d2?w=800&q=80"
    ]
  },
  {
    id: "kims-secunderabad",
    name: "KIMS Hospital",
    city: "Hyderabad",
    area: "Secunderabad",
    address: "1-8-31/1, Minister Road, Secunderabad — 500003",
    lat: 17.4411,
    lng: 78.4987,
    map_link: "https://maps.google.com/?q=KIMS+Hospital+Secunderabad",
    rating: 4.2,
    type: "Corporate",
    doctors_count: 195,
    facilities: ["ICU", "NICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Cath Lab"],
    amenities: ["Parking", "Cafeteria", "Wifi", "ATM"],
    specialties: ["Orthopedics", "Cardiology", "Neurosurgery", "Pediatrics", "Obstetrics", "Dermatology"],
    best_for: ["Orthopedic Surgeries", "Pediatric Care", "Maternity"],
    pros: ["Excellent orthopedic team", "Affordable for corporate hospital", "Good maternity ward", "Central Secunderabad location"],
    cons: ["OPD can be crowded", "Appointments sometimes delayed by 1–2 hours", "Limited parking on weekdays"],
    emergency_score: 82,
    affordability_score: 3,
    waiting_time: "40–75 min OPD",
    travel_time: "10 min from Paradise Circle",
    images: [
      "https://images.unsplash.com/photo-1538108149393-fbbd81895907?w=800&q=80",
      "https://images.unsplash.com/photo-1504439468489-c8920d796a29?w=800&q=80"
    ]
  },
  {
    id: "care-hospitals-banjara",
    name: "Care Hospitals",
    city: "Hyderabad",
    area: "Banjara Hills",
    address: "Road No. 1, Banjara Hills, Hyderabad — 500034",
    lat: 17.4152,
    lng: 78.4407,
    map_link: "https://maps.google.com/?q=Care+Hospitals+Banjara+Hills",
    rating: 4.1,
    type: "Corporate",
    doctors_count: 160,
    facilities: ["ICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Dialysis"],
    amenities: ["Parking", "Cafeteria", "Wifi"],
    specialties: ["Cardiology", "Oncology", "Transplant Surgery", "Neurology", "Endocrinology"],
    best_for: ["Oncology", "Liver Transplant", "Cardiac Interventions"],
    pros: ["Strong liver transplant program", "Good oncology unit", "Friendly staff experience", "Banjara Hills location convenient"],
    cons: ["Smaller campus vs Apollo", "Specialist slots book fast", "ICU capacity limited vs larger hospitals"],
    emergency_score: 78,
    affordability_score: 3,
    waiting_time: "35–65 min OPD",
    travel_time: "25 min from Hitech City",
    images: [
      "https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&q=80",
      "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&q=80"
    ]
  },
  {
    id: "aig-hospitals-gachibowli",
    name: "AIG Hospitals",
    city: "Hyderabad",
    area: "Gachibowli",
    address: "Survey No. 1, Mindspace Road, Gachibowli — 500032",
    lat: 17.4401,
    lng: 78.3489,
    map_link: "https://maps.google.com/?q=AIG+Hospitals+Gachibowli+Hyderabad",
    rating: 4.4,
    type: "Corporate",
    doctors_count: 210,
    facilities: ["ICU", "NICU", "Cath Lab", "MRI", "CT Scan", "Endoscopy Suite", "Blood Bank", "24/7 Pharmacy", "Ambulance"],
    amenities: ["Valet Parking", "Food Court", "Wifi", "International Patient Lounge", "ATM"],
    specialties: ["Gastroenterology", "Hepatology", "Bariatric Surgery", "Colorectal Surgery", "Pancreatic Surgery"],
    best_for: ["GI Disorders", "Liver Diseases", "Bariatric Surgery", "Endoscopic Procedures"],
    pros: ["Asia's largest GI hospital", "World-class endoscopy setup", "Hitech City proximity", "Strong research program"],
    cons: ["Primarily GI focused — limited for other specialties", "High volume means wait times", "Premium pricing"],
    emergency_score: 80,
    affordability_score: 2,
    waiting_time: "50–80 min OPD",
    travel_time: "5 min from Financial District",
    images: [
      "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&q=80",
      "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&q=80"
    ]
  },
  {
    id: "gleneagles-aware-lbagar",
    name: "Gleneagles Aware",
    city: "Hyderabad",
    area: "LB Nagar",
    address: "Plot No. 1, LB Nagar, Hyderabad — 500074",
    lat: 17.3519,
    lng: 78.5474,
    map_link: "https://maps.google.com/?q=Gleneagles+Aware+LB+Nagar+Hyderabad",
    rating: 4.0,
    type: "Corporate",
    doctors_count: 150,
    facilities: ["ICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Cath Lab"],
    amenities: ["Parking", "Cafeteria", "Wifi", "ATM"],
    specialties: ["Cardiology", "Orthopedics", "Neurology", "Obstetrics", "General Surgery"],
    best_for: ["South Hyderabad Residents", "Cardiac Procedures", "Maternity Care"],
    pros: ["Best hospital in LB Nagar zone", "Good emergency setup", "Affordable compared to city center hospitals"],
    cons: ["Limited super-specialty options", "Moderate infrastructure age", "Heavy outpatient load on weekdays"],
    emergency_score: 76,
    affordability_score: 3,
    waiting_time: "45–70 min OPD",
    travel_time: "10 min from LB Nagar Metro",
    images: [
      "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?w=800&q=80",
      "https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=800&q=80"
    ]
  },
  {
    id: "omni-kothapet",
    name: "Omni Hospitals",
    city: "Hyderabad",
    area: "Kothapet",
    address: "Plot 4, Dilsukhnagar, Kothapet, Hyderabad — 500060",
    lat: 17.3713,
    lng: 78.5297,
    map_link: "https://maps.google.com/?q=Omni+Hospitals+Kothapet+Hyderabad",
    rating: 3.9,
    type: "Private",
    doctors_count: 110,
    facilities: ["ICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance"],
    amenities: ["Parking", "Cafeteria", "Wifi"],
    specialties: ["General Surgery", "Orthopedics", "ENT", "Ophthalmology", "Gynecology"],
    best_for: ["General Surgery", "Dilsukhnagar Area", "Budget Care"],
    pros: ["Affordable pricing", "Convenient for east Hyderabad", "Short waiting times", "Friendly outpatient experience"],
    cons: ["Limited super-specialty facilities", "No advanced imaging like PET Scan", "Smaller ICU capacity"],
    emergency_score: 68,
    affordability_score: 4,
    waiting_time: "20–40 min OPD",
    travel_time: "10 min from Kothapet Metro",
    images: [
      "https://images.unsplash.com/photo-1643297654416-05795d62e39c?w=800&q=80",
      "https://images.unsplash.com/photo-1585435557343-3b092031a831?w=800&q=80"
    ]
  },
  {
    id: "osmania-general",
    name: "Osmania General Hospital",
    city: "Hyderabad",
    area: "Afzalgunj",
    address: "Afzalgunj, Hyderabad — 500012",
    lat: 17.3803,
    lng: 78.4761,
    map_link: "https://maps.google.com/?q=Osmania+General+Hospital+Hyderabad",
    rating: 3.5,
    type: "Government",
    doctors_count: 400,
    facilities: ["ICU", "NICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Trauma Centre", "Casualty"],
    amenities: ["Free Treatment", "Free Medicines (Scheme)", "Parking"],
    specialties: ["General Medicine", "Surgery", "Gynecology", "Pediatrics", "Neurology", "Orthopedics", "Psychiatry", "Cardiology"],
    best_for: ["Free/Low-cost care", "Government scheme patients", "Emergency Trauma", "Teaching hospital cases"],
    pros: ["Free treatment under government schemes", "Large capacity", "Good trauma setup", "Experienced resident doctors"],
    cons: ["Very long waiting times", "Infrastructure needs upgrade", "Overcrowding", "Inconsistent specialist availability"],
    emergency_score: 85,
    affordability_score: 5,
    waiting_time: "2–5 hours OPD",
    travel_time: "15 min from Nampally station",
    images: [
      "https://images.unsplash.com/photo-1618498082410-b4aa22193b38?w=800&q=80",
      "https://images.unsplash.com/photo-1576669801775-ff43c5ab079d?w=800&q=80"
    ]
  },
  {
    id: "nims-punjagutta",
    name: "NIMS — Nizams Institute",
    city: "Hyderabad",
    area: "Punjagutta",
    address: "Panjagutta, Hyderabad — 500082",
    lat: 17.4318,
    lng: 78.4502,
    map_link: "https://maps.google.com/?q=NIMS+Hyderabad+Punjagutta",
    rating: 3.8,
    type: "Government",
    doctors_count: 350,
    facilities: ["ICU", "NICU", "Cath Lab", "MRI", "CT Scan", "PET Scan", "Bone Marrow Transplant", "Blood Bank", "Ambulance"],
    amenities: ["Free Treatment", "Subsidised Pharmacy", "Canteen"],
    specialties: ["Haematology", "Bone Marrow Transplant", "Cardiology", "Neurosurgery", "Nephrology", "Endocrinology"],
    best_for: ["Blood Disorders", "Bone Marrow Transplant", "Rare Diseases", "Government Scheme Patients"],
    pros: ["Advanced haematology setup", "Bone marrow transplant facility", "Subsidised costs", "Strong specialist pool"],
    cons: ["Overloaded outpatient", "Very long wait for appointments", "Limited amenities", "Documentation delays"],
    emergency_score: 80,
    affordability_score: 5,
    waiting_time: "1–3 hours OPD",
    travel_time: "20 min from Hitech City",
    images: [
      "https://images.unsplash.com/photo-1620507387308-8f7b93687484?w=800&q=80",
      "https://images.unsplash.com/photo-1612531385446-f7e6d131e1d0?w=800&q=80"
    ]
  },
  {
    id: "maxcure-madhapur",
    name: "Maxcure Hospitals",
    city: "Hyderabad",
    area: "Madhapur",
    address: "Hitec City Main Road, Madhapur — 500081",
    lat: 17.4486,
    lng: 78.3908,
    map_link: "https://maps.google.com/?q=Maxcure+Hospitals+Madhapur",
    rating: 4.0,
    type: "Private",
    doctors_count: 130,
    facilities: ["ICU", "MRI", "CT Scan", "Blood Bank", "24/7 Pharmacy", "Ambulance", "Cath Lab"],
    amenities: ["Parking", "Cafeteria", "Wifi", "ATM"],
    specialties: ["Cardiology", "Neurology", "Orthopedics", "Urology", "Oncology"],
    best_for: ["IT Corridor Residents", "Hitech City Area", "Second Opinion"],
    pros: ["Convenient for Hitech City workers", "Good cardiac setup", "Clean modern facility", "Reasonable pricing"],
    cons: ["Medium-sized team", "Specialist availability not 24/7 for all departments", "Limited super-specialty"],
    emergency_score: 74,
    affordability_score: 3,
    waiting_time: "30–55 min OPD",
    travel_time: "3 min from Hitech City Metro",
    images: [
      "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=800&q=80",
      "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?w=800&q=80"
    ]
  },
  {
    id: "continental-hospitals-gachibowli",
    name: "Continental Hospitals",
    city: "Hyderabad",
    area: "Gachibowli",
    address: "IT & Financial District, Gachibowli — 500032",
    lat: 17.4367,
    lng: 78.3559,
    map_link: "https://maps.google.com/?q=Continental+Hospitals+Gachibowli",
    rating: 4.2,
    type: "Corporate",
    doctors_count: 175,
    facilities: ["ICU", "NICU", "Cath Lab", "MRI", "CT Scan", "Robotic Surgery", "Blood Bank", "24/7 Pharmacy", "Ambulance"],
    amenities: ["Valet Parking", "Cafeteria", "Wifi", "International Desk", "ATM"],
    specialties: ["Robotic Surgery", "Cardiology", "Oncology", "Bariatrics", "Orthopedics", "Transplant"],
    best_for: ["Robotic Surgeries", "Minimally Invasive Procedures", "IT Corridor Patients"],
    pros: ["JCI accredited", "Strong robotic surgery program", "Modern campus", "Good international patient support"],
    cons: ["Very high billing", "Distance from old city", "Specialist wait times high for super-specialty"],
    emergency_score: 85,
    affordability_score: 2,
    waiting_time: "40–70 min OPD",
    travel_time: "8 min from Financial District",
    images: [
      "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=800&q=80",
      "https://images.unsplash.com/photo-1588776814546-1ffbb041c4e2?w=800&q=80"
    ]
  },
  {
    id: "sunshine-secunderabad",
    name: "Sunshine Hospitals",
    city: "Hyderabad",
    area: "Secunderabad",
    address: "PG Road, Secunderabad — 500003",
    lat: 17.4445,
    lng: 78.5015,
    map_link: "https://maps.google.com/?q=Sunshine+Hospitals+Secunderabad",
    rating: 4.1,
    type: "Private",
    doctors_count: 140,
    facilities: ["ICU", "MRI", "CT Scan", "Arthroscopy Suite", "Blood Bank", "24/7 Pharmacy", "Ambulance"],
    amenities: ["Parking", "Cafeteria", "Wifi"],
    specialties: ["Orthopedics", "Sports Medicine", "Spine Surgery", "Trauma", "Physiotherapy"],
    best_for: ["Sports Injuries", "Spine Disorders", "Joint Replacements", "Trauma Cases"],
    pros: ["Best orthopedic focus in city", "Sports medicine specialists", "Good physiotherapy wing", "Reasonable cost vs Apollo"],
    cons: ["Limited non-orthopedic specialties", "Small ICU for general medicine", "No oncology"],
    emergency_score: 72,
    affordability_score: 3,
    waiting_time: "25–50 min OPD",
    travel_time: "12 min from Secunderabad station",
    images: [
      "https://images.unsplash.com/photo-1519494080410-f9aa76cb4283?w=800&q=80",
      "https://images.unsplash.com/photo-1551076805-e1869033e561?w=800&q=80"
    ]
  }
];

// ── Public API ───────────────────────────────────────────────────────────────

let _allHospitals = null; // in-memory cache

async function ensureSeedData() {
  const snap = await db.collection(HOSPITALS_COLLECTION).limit(1).get();
  if (snap.empty) {
    console.log("[ArogyaX] Seeding Firestore with hospital data...");
    const batch = db.batch();
    SEED_HOSPITALS.forEach(h => {
      const { id, ...data } = h;
      batch.set(db.collection(HOSPITALS_COLLECTION).doc(id), data);
    });
    await batch.commit();
    console.log("[ArogyaX] Seed complete.");
  }
}

async function fetchAllHospitals() {
  if (_allHospitals) return _allHospitals;
  await ensureSeedData();
  const snap = await db.collection(HOSPITALS_COLLECTION).get();
  _allHospitals = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  return _allHospitals;
}

async function fetchHospitalById(id) {
  if (_allHospitals) {
    const found = _allHospitals.find(h => h.id === id);
    if (found) return found;
  }
  await ensureSeedData();
  const doc = await db.collection(HOSPITALS_COLLECTION).doc(id).get();
  if (doc.exists) return { id: doc.id, ...doc.data() };
  return null;
}

function invalidateCache() { _allHospitals = null; }
