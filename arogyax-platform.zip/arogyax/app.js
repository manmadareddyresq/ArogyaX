// app.js — shared utilities across all pages

// ── Compare State ────────────────────────────────────────────────────────────
const CompareState = {
  KEY: "arogyax_compare",
  get() { try { return JSON.parse(localStorage.getItem(this.KEY) || "[]"); } catch { return []; } },
  set(ids) { localStorage.setItem(this.KEY, JSON.stringify(ids)); this._notify(); },
  add(id) { const ids = this.get(); if (!ids.includes(id) && ids.length < 4) { ids.push(id); this.set(ids); } },
  remove(id) { this.set(this.get().filter(x => x !== id)); },
  toggle(id) { this.get().includes(id) ? this.remove(id) : this.add(id); },
  has(id) { return this.get().includes(id); },
  count() { return this.get().length; },
  clear() { this.set([]); },
  _notify() { document.dispatchEvent(new CustomEvent("compare-changed")); }
};

// ── Compare UI ────────────────────────────────────────────────────────────────
function updateCompareUI() {
  const count = CompareState.count();
  document.querySelectorAll(".compare-badge").forEach(el => el.textContent = count);
  const bar = document.getElementById("compareBar");
  if (bar) {
    bar.classList.toggle("visible", count > 0);
    const txt = document.getElementById("compareBarText");
    if (txt) txt.textContent = `${count} hospital${count !== 1 ? "s" : ""} selected for comparison`;
  }
}

document.addEventListener("compare-changed", updateCompareUI);
document.addEventListener("DOMContentLoaded", () => {
  updateCompareUI();
  initNav();
  initScrollReveal();
  initHamburger();
});

// ── Nav ──────────────────────────────────────────────────────────────────────
function initNav() {
  const navbar = document.getElementById("navbar");
  if (!navbar) return;
  window.addEventListener("scroll", () => {
    navbar.classList.toggle("scrolled", window.scrollY > 20);
  }, { passive: true });
}

function initHamburger() {
  const btn = document.getElementById("hamburger");
  const menu = document.getElementById("mobileMenu");
  if (!btn || !menu) return;
  btn.addEventListener("click", () => {
    menu.classList.toggle("open");
    btn.classList.toggle("active");
  });
}

// ── Scroll Reveal ─────────────────────────────────────────────────────────────
function initScrollReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) { e.target.classList.add("revealed"); obs.unobserve(e.target); }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll(".reveal").forEach(el => obs.observe(el));
}

// ── Hospital Card Builder ──────────────────────────────────────────────────────
function affordabilityLabel(score) {
  const map = { 1: "$$$$", 2: "$$$", 3: "$$", 4: "$", 5: "Free/Subsidised" };
  return map[score] || "$$";
}

function affordabilityColor(score) {
  if (score >= 4) return "#22c55e";
  if (score === 3) return "#f59e0b";
  return "#ef4444";
}

function emergencyBadge(score) {
  if (score >= 85) return { label: "High", cls: "emg-high" };
  if (score >= 70) return { label: "Medium", cls: "emg-mid" };
  return { label: "Basic", cls: "emg-low" };
}

function buildHospitalCard(h, opts = {}) {
  const inCompare = CompareState.has(h.id);
  const img = (h.images && h.images[0]) || "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?w=600&q=70";
  const emg = emergencyBadge(h.emergency_score || 0);
  const bestFor = (h.best_for || []).slice(0, 2).map(b => `<span class="tag">${sanitize(b)}</span>`).join("");
  const compBtnLabel = inCompare ? "✓ Added" : "+ Compare";
  const compBtnCls = inCompare ? "btn-compare added" : "btn-compare";

  return `
    <div class="hospital-card reveal" data-id="${sanitize(h.id)}">
      <div class="card-img-wrap">
        <img src="${sanitize(img)}" alt="${sanitize(h.name)}" loading="lazy"
          onerror="this.src='https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=600&q=70'">
        <span class="type-badge ${getTypeBadgeClass(h.type)}">${sanitize(h.type)}</span>
        <span class="emg-badge ${emg.cls}">⚡ ${emg.label} Emergency</span>
      </div>
      <div class="card-body">
        <div class="card-header-row">
          <h3 class="card-name"><a href="hospital.html?id=${sanitize(h.id)}">${sanitize(h.name)}</a></h3>
          <div class="card-rating">⭐ <b>${h.rating}</b></div>
        </div>
        <div class="card-area">📍 ${sanitize(h.area)}</div>
        <div class="card-tags">${bestFor}</div>
        <div class="card-meta-row">
          <span class="afford" style="color:${affordabilityColor(h.affordability_score)}">
            ${affordabilityLabel(h.affordability_score)}
          </span>
          <span class="wait">⏱ ${sanitize(h.waiting_time || "N/A")}</span>
        </div>
        <div class="card-actions">
          <button class="${compBtnCls}" onclick="toggleCompare('${sanitize(h.id)}', this)">${compBtnLabel}</button>
          <a href="${sanitize(h.map_link || '#')}" target="_blank" class="btn-directions" rel="noopener noreferrer" title="Get Directions">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polygon points="3 11 22 2 13 21 11 13 3 11"/>
            </svg>
          </a>
          <a href="hospital.html?id=${sanitize(h.id)}" class="btn-view">View →</a>
        </div>
      </div>
    </div>
  `;
}

function toggleCompare(id, btn) {
  CompareState.toggle(id);
  const inComp = CompareState.has(id);
  document.querySelectorAll(`[data-id="${id}"] .btn-compare`).forEach(b => {
    b.textContent = inComp ? "✓ Added" : "+ Compare";
    b.classList.toggle("added", inComp);
  });
  updateCompareUI();
}

function clearCompare() { CompareState.clear(); updateCompareUI(); }

function filterChip(specialty) {
  window.location.href = `hospitals.html?specialty=${encodeURIComponent(specialty)}`;
}

function triggerHeroSearch() {
  const q = document.getElementById("heroSearchInput")?.value?.trim();
  if (q) window.location.href = `hospitals.html?search=${encodeURIComponent(q)}`;
}
