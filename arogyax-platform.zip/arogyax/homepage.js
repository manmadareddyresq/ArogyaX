// homepage.js
const TOP_HOSPITAL_IDS = [
  "apollo-jubilee-hills",
  "yashoda-secunderabad",
  "kims-secunderabad",
  "care-hospitals-banjara",
  "aig-hospitals-gachibowli",
  "continental-hospitals-gachibowli"
];

let navSearch, heroSearch;

document.addEventListener("DOMContentLoaded", async () => {
  // Init searches with empty list first
  navSearch = new SearchEngine({
    inputEl: document.getElementById("navSearchInput"),
    dropdownEl: document.getElementById("navDropdown"),
    onSelect: (id) => { window.location.href = `hospital.html?id=${id}`; }
  });
  heroSearch = new SearchEngine({
    inputEl: document.getElementById("heroSearchInput"),
    dropdownEl: document.getElementById("heroDropdown"),
    onSelect: (id) => { window.location.href = `hospital.html?id=${id}`; }
  });

  const grid = document.getElementById("topHospitalsGrid");
  try {
    const all = await fetchAllHospitals();
    navSearch.setHospitals(all);
    heroSearch.setHospitals(all);

    // Show top hospitals in order
    const top = TOP_HOSPITAL_IDS
      .map(id => all.find(h => h.id === id))
      .filter(Boolean);

    grid.innerHTML = top.map(h => buildHospitalCard(h)).join("");
    initScrollReveal();
  } catch (err) {
    console.error("[ArogyaX]", err);
    grid.innerHTML = `<div class="error-msg">Failed to load hospitals. Please refresh.</div>`;
  }
});
